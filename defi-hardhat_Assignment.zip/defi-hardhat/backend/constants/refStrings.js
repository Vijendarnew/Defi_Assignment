'use strict';

let refString = {}
refString.user = 'User'
refString.admin = 'Admin'
refString.success = "Success"

module.exports = refString