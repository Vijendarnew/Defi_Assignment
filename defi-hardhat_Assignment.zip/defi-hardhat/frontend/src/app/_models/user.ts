export class User {
  account: string;
  pkey: string;
}
