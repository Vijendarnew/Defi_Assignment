export class BackendResponse {
  timestamp: string;
  statusCode: number;
  data: any;
}
